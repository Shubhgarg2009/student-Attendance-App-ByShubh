import firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyDL5iv8wNyMIkqIcm3GLNF_eOsW5ww29eA",
  authDomain: "fruit-f3f47.firebaseapp.com",
  databaseURL: "https://fruit-f3f47-default-rtdb.firebaseio.com",
  projectId: "fruit-f3f47",
  storageBucket: "fruit-f3f47.appspot.com",
  messagingSenderId: "967998087271",
  appId: "1:967998087271:web:6626c2bad5024d703574c2"
};
   // Initialize Firebase
   if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export default  firebase.database();